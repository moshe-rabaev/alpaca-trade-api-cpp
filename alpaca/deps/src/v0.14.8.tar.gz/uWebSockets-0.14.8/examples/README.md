More examples can be seen in test/main.cpp
